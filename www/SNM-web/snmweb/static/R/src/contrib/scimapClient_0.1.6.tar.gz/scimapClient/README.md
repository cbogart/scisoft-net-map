scimapClient
============

This R package collects information about what other packages are installed and what
their dependencies are, and submits them to a server where users and package authors
can monitor usage trends.

The server software is [SNM](https://github.com/cbogart/SNM).

