library(testthat)
library(scimapClient)

test_check("scimapClient")
